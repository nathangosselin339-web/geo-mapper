package com.geomapping;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GeoMappingMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("geomapping");
    private static final String PYTHON_HOST = "127.0.0.1";
    private static final int PYTHON_PORT = 19528;

    @Override
    public void onInitialize() {
        LOGGER.info("GeoMapping mod initializing...");

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608()) return class_1269.field_5811;
            if (player.method_5998(hand).method_7960()) return class_1269.field_5811;

            class_2338 pos = hitResult.method_17777().method_10093(hitResult.method_17780());
            class_2680 state = world.method_8320(pos);
            class_2960 blockId = class_7923.field_41175.method_10221(state.method_26204());

            String json = String.format(
                "{\"type\":\"block_place\",\"x\":%d,\"y\":%d,\"z\":%d,\"block\":\"%s\"}",
                pos.method_10263(), pos.method_10264(), pos.method_10260(), blockId.toString()
            );

            sendToPython(json);
            return class_1269.field_5811;
        });
    }

    private void sendToPython(String data) {
        try (Socket sock = new Socket(PYTHON_HOST, PYTHON_PORT);
             OutputStream out = sock.getOutputStream()) {
            out.write(data.getBytes(StandardCharsets.UTF_8));
            out.flush();
        } catch (Exception e) {
            LOGGER.warn("Failed to send to Python: {}", e.getMessage());
        }
    }
}
